<?php
	$portfolio=[
		["img" => "1", "name"=>"Threads", "description"=>"Illustration"],
		["img" => "2", "name"=>"Explore", "description"=>"Graphic Design"],
		["img" => "3", "name"=>"Finish", "description"=>"Identity"],
		["img" => "4", "name"=>"Lines", "description"=>"Branding"],
		["img" => "5", "name"=>"Southwest", "description"=>"Website Design"],
		["img" => "6", "name"=>"Window", "description"=>"Photography"]
	];
	
	shuffle($portfolio);
	$sequence=array_slice($portfolio,0, 3);
	echo json_encode($sequence);
?>