<?php
	$titles=[
		  "title1" => "Benvenuti!",
		  "title2" => "Il nostro sito web"
		];
	echo json_encode($titles);

?>