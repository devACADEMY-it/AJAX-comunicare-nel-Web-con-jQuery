<!--

	Lezione del corso
	AJAX, comunicare nel Web con jQuery

	Disponibile su devACADEMY.it

-->

<?php
header("Access-Control-Allow-Origin: *");
echo "Ciao a tutti";
?>