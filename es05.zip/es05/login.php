<!--

	Lezione del corso
	AJAX, comunicare nel Web con jQuery

	Disponibile su devACADEMY.it

-->

<?php
  if (array_key_exists("username", $_POST) &&
	array_key_exists("password", $_POST) &&
           strlen($_POST['username'])>0 && strlen($_POST['password'])>0)
 {
  if  ($_POST['password']==strtoupper($_POST['username'])."123")
	echo "OK";
   else
	echo "KO";
}
else
   echo "ERROR";

?>