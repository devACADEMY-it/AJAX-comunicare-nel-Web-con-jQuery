<!--

	Lezione del corso
	AJAX, comunicare nel Web con jQuery

	Disponibile su devACADEMY.it

-->

<?php

  // simuliamo risposta onerosa aspettando 5 secondi

  sleep(5);

  echo "Dati remoti...provenienti dal SERVER";
?>